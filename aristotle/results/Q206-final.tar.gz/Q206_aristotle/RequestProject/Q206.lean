/-
Q206 — Principia Mathematica, first edition, volume I (1910),
✱2·2, ✱2·21 and ✱2·24 (printed pp. 108–109).

Standalone: no imports, no axioms, no `sorry`, no automation beyond the
primitive rules ✱1·1–✱1·6 and the earlier results ✱2·04, ✱2·05.
-/

namespace PM
inductive RealType where | elementaryProposition : RealType
abbrev RealContext := List RealType
inductive RealVar : (Γ : RealContext) → RealType → Type where
  | zero : RealVar (τ :: Γ) τ
  | succ : RealVar Γ τ → RealVar (σ :: Γ) τ
inductive Elementary : RealContext → Type where
  | constant : String → Elementary Γ
  | var : RealVar Γ .elementaryProposition → Elementary Γ
  | neg : Elementary Γ → Elementary Γ
  | disj : Elementary Γ → Elementary Γ → Elementary Γ
namespace Elementary
prefix:max "∼ₚ" => neg
infixr:55 " ∨ₚ " => disj
def imp (p q : Elementary Γ) := disj (neg p) q
infixr:54 " ⊃ₚ " => imp
end Elementary
inductive Derivation : {Γ : RealContext} → Elementary Γ → Prop where
  | star_1_1 {p q : Elementary []} : Derivation p → Derivation (p ⊃ₚ q) → Derivation q
  | star_1_11 {Γ} {φ ψ : Elementary Γ} (h : Γ ≠ []) : Derivation φ → Derivation (φ ⊃ₚ ψ) → Derivation ψ
  | star_1_2 {Γ} (p : Elementary Γ) : Derivation ((p ∨ₚ p) ⊃ₚ p)
  | star_1_3 {Γ} (p q : Elementary Γ) : Derivation (q ⊃ₚ (p ∨ₚ q))
  | star_1_4 {Γ} (p q : Elementary Γ) : Derivation ((p ∨ₚ q) ⊃ₚ (q ∨ₚ p))
  | star_1_5 {Γ} (p q r : Elementary Γ) : Derivation ((p ∨ₚ (q ∨ₚ r)) ⊃ₚ (q ∨ₚ (p ∨ₚ r)))
  | star_1_6 {Γ} (p q r : Elementary Γ) : Derivation ((q ⊃ₚ r) ⊃ₚ ((p ∨ₚ q) ⊃ₚ (p ∨ₚ r)))
notation:45 "⊢ₚ " p => Derivation p
namespace Derivation
theorem detach {Γ} {φ ψ : Elementary Γ} (hφ : Derivation φ)
    (hφψ : Derivation (φ ⊃ₚ ψ)) : Derivation ψ := by
  cases Γ with
  | nil => exact Derivation.star_1_1 hφ hφψ
  | cons τ Δ => exact Derivation.star_1_11 (by simp) hφ hφψ
end Derivation
end PM

namespace PM.FirstEdition.Volume1.Star2
theorem star_2_04 {Γ} (p q r : PM.Elementary Γ) :
    ⊢ₚ ((p ⊃ₚ (q ⊃ₚ r)) ⊃ₚ (q ⊃ₚ (p ⊃ₚ r))) :=
  PM.Derivation.star_1_5 (∼ₚ p) (∼ₚ q) r
theorem star_2_05 {Γ} (p q r : PM.Elementary Γ) :
    ⊢ₚ ((q ⊃ₚ r) ⊃ₚ ((p ⊃ₚ q) ⊃ₚ (p ⊃ₚ r))) :=
  PM.Derivation.star_1_6 (∼ₚ p) q r

/-- ✱2·2. `⊢ : p . ⊃ . p ∨ q`, in the printed three stages:
`Add` (✱1·3) gives `p ⊃ q ∨ p`, `Perm` (✱1·4) gives `q ∨ p ⊃ p ∨ q`,
and `Syll`, expanded by ✱2·05 together with `PM.Derivation.detach`,
composes them. -/
theorem star_2_2 {Γ} (p q : PM.Elementary Γ) :
    ⊢ₚ (p ⊃ₚ (p ∨ₚ q)) := by
  -- Add: ✱1·3, with `q/p` and `p/q`
  have hAdd : ⊢ₚ (p ⊃ₚ (q ∨ₚ p)) := PM.Derivation.star_1_3 q p
  -- Perm: ✱1·4, with `q/p` and `p/q`
  have hPerm : ⊢ₚ ((q ∨ₚ p) ⊃ₚ (p ∨ₚ q)) := PM.Derivation.star_1_4 q p
  -- Syll: ✱2·05 with `p/p`, `q ∨ p / q`, `p ∨ q / r`
  have hSyll : ⊢ₚ (((q ∨ₚ p) ⊃ₚ (p ∨ₚ q)) ⊃ₚ
      ((p ⊃ₚ (q ∨ₚ p)) ⊃ₚ (p ⊃ₚ (p ∨ₚ q)))) := star_2_05 p (q ∨ₚ p) (p ∨ₚ q)
  exact PM.Derivation.detach hAdd (PM.Derivation.detach hPerm hSyll)

/-- ✱2·21. `⊢ : ∼p . ⊃ . p ⊃ q`, which is exactly ✱2·2 with `∼p/p`
(`∼p ∨ q` being `p ⊃ q`). -/
theorem star_2_21 {Γ} (p q : PM.Elementary Γ) :
    ⊢ₚ (∼ₚ p ⊃ₚ (p ⊃ₚ q)) := by
  exact star_2_2 (∼ₚ p) q

/-- ✱2·24. `⊢ : p . ⊃ . ∼p ⊃ q`, obtained as `[✱2·21.Comm]`: ✱2·04 applied to
the exact statement of ✱2·21, then detached. -/
theorem star_2_24 {Γ} (p q : PM.Elementary Γ) :
    ⊢ₚ (p ⊃ₚ (∼ₚ p ⊃ₚ q)) := by
  -- Comm: ✱2·04 with `∼p/p`, `p/q`, `q/r`
  have hComm : ⊢ₚ ((∼ₚ p ⊃ₚ (p ⊃ₚ q)) ⊃ₚ (p ⊃ₚ (∼ₚ p ⊃ₚ q))) :=
    star_2_04 (∼ₚ p) p q
  exact PM.Derivation.detach (star_2_21 p q) hComm
end PM.FirstEdition.Volume1.Star2
