/-
# Q207 — Principia Mathematica, first edition, volume I (1910), ✱2·25–✱2·27

Formalization of ✱2·25, ✱2·26, ✱2·27 (printed p. 109) in a syntactic
derivation system for the propositional part of PM.

No axioms beyond the printed primitive propositions, no semantic reasoning,
no generic substitution schema, no `sorry`.
-/

namespace PM

inductive RealType where | elementaryProposition : RealType

abbrev RealContext := List RealType

inductive RealVar : (Γ : RealContext) → RealType → Type where
  | zero : RealVar (τ::Γ) τ
  | succ : RealVar Γ τ → RealVar (σ::Γ) τ

inductive Elementary : RealContext → Type where
  | constant : String → Elementary Γ
  | var : RealVar Γ .elementaryProposition → Elementary Γ
  | neg : Elementary Γ → Elementary Γ
  | disj : Elementary Γ → Elementary Γ → Elementary Γ

namespace Elementary

prefix:max "∼ₚ" => neg
infixr:55 " ∨ₚ " => disj

def imp (p q : Elementary Γ) := disj (neg p) q

infixr:54 " ⊃ₚ " => imp

end Elementary

inductive Derivation : {Γ : RealContext} → Elementary Γ → Prop where
  | star_1_1 {p q : Elementary []} : Derivation p → Derivation (p ⊃ₚ q) → Derivation q
  | star_1_11 {Γ} {φ ψ : Elementary Γ} (h : Γ ≠ []) : Derivation φ → Derivation (φ ⊃ₚ ψ) → Derivation ψ
  | star_1_2 {Γ} (p : Elementary Γ) : Derivation ((p ∨ₚ p) ⊃ₚ p)
  | star_1_3 {Γ} (p q : Elementary Γ) : Derivation (q ⊃ₚ (p ∨ₚ q))
  | star_1_4 {Γ} (p q : Elementary Γ) : Derivation ((p ∨ₚ q) ⊃ₚ (q ∨ₚ p))
  | star_1_5 {Γ} (p q r : Elementary Γ) : Derivation ((p ∨ₚ (q ∨ₚ r)) ⊃ₚ (q ∨ₚ (p ∨ₚ r)))
  | star_1_6 {Γ} (p q r : Elementary Γ) : Derivation ((q ⊃ₚ r) ⊃ₚ ((p ∨ₚ q) ⊃ₚ (p ∨ₚ r)))

notation:45 "⊢ₚ " p => Derivation p

namespace Derivation

theorem detach {Γ} {φ ψ : Elementary Γ} (hφ : Derivation φ) (h : Derivation (φ ⊃ₚ ψ)) :
    Derivation ψ := by
  cases Γ with
  | nil => exact Derivation.star_1_1 hφ h
  | cons τ Δ => exact Derivation.star_1_11 (by simp) hφ h

end Derivation

end PM

namespace PM.FirstEdition.Volume1.Star2

/-- ✱2·1. ⊢ . ∼p ∨ p -/
theorem star_2_1 {Γ} (p : PM.Elementary Γ) : ⊢ₚ (∼ₚ p ∨ₚ p) := by
  have h07 : ⊢ₚ (p ⊃ₚ (p ∨ₚ p)) := PM.Derivation.star_1_3 p p
  have hsum := PM.Derivation.star_1_6 (∼ₚ p) (p ∨ₚ p) p
  have hstep := PM.Derivation.detach (PM.Derivation.star_1_2 p) hsum
  exact PM.Derivation.detach h07 hstep

/-- ✱2·25. ⊢ :· p : ∨ : p ∨ q . ⊃ . q

Proof: ✱2·1 instantiated at `p ∨ q` gives `∼(p ∨ q) ∨ (p ∨ q)`; Assoc (✱1·5)
instantiated as printed turns this into `p ∨ (∼(p ∨ q) ∨ q)`, which by ✱1·01
is the target. -/
theorem star_2_25 {Γ} (p q : PM.Elementary Γ) :
    ⊢ₚ (p ∨ₚ ((p ∨ₚ q) ⊃ₚ q)) := by
  have h21 : ⊢ₚ (∼ₚ (p ∨ₚ q) ∨ₚ (p ∨ₚ q)) := star_2_1 (p ∨ₚ q)
  have hassoc := PM.Derivation.star_1_5 (∼ₚ (p ∨ₚ q)) p q
  exact PM.Derivation.detach h21 hassoc

/-- ✱2·26. ⊢ :· ∼p : ∨ : p ⊃ q . ⊃ . q  — this is `[✱2·25 ∼p/p]`. -/
theorem star_2_26 {Γ} (p q : PM.Elementary Γ) :
    ⊢ₚ (∼ₚ p ∨ₚ ((p ⊃ₚ q) ⊃ₚ q)) :=
  star_2_25 (∼ₚ p) q

/-- ✱2·27. ⊢ :· p : ⊃ : p ⊃ q . ⊃ . q  — the ✱1·01 reading of ✱2·26. -/
theorem star_2_27 {Γ} (p q : PM.Elementary Γ) :
    ⊢ₚ (p ⊃ₚ ((p ⊃ₚ q) ⊃ₚ q)) :=
  star_2_26 p q

end PM.FirstEdition.Volume1.Star2
